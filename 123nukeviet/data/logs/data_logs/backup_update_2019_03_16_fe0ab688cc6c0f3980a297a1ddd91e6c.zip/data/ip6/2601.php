<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:28:19 GMT
 */

$ranges = array('2601::/20'=>'US');
