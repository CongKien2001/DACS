<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:28:33 GMT
 */

$ranges = array('2c0e::/20'=>'EG','2c0e:2000::/20'=>'ZA','2c0e:4000::/24'=>'ZA','2c0e:7f80::/27'=>'CI');
