<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:28:19 GMT
 */

$ranges = array('2408::/22'=>'JP','2408:4000::/22'=>'CN','2408:8000::/20'=>'CN');
