<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:20:26 GMT
 */

$ranges=array(1660944384=>array(1666731329,'US'),1666731330=>array(1666731330,'FR'),1666731331=>array(1673527295,'US'),1673527296=>array(1673560063,'CA'),1673560064=>array(1673986047,'US'),1673986048=>array(1674051583,'CA'),1674051584=>array(1674575871,'US'),1674575872=>array(1677721599,'CA'));
