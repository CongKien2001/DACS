<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:55 GMT
 */

$ranges=array(150994944=>array(151521029,'US'),151521030=>array(151521030,'FR'),151521031=>array(151587080,'US'),151587081=>array(151587081,'FR'),151587082=>array(167772159,'US'));
