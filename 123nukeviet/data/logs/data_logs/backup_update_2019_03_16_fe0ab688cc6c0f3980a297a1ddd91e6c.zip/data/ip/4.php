<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:55 GMT
 */

$ranges=array(67108864=>array(68169727,'US'),68169728=>array(68171775,'CA'),68171776=>array(68194815,'US'),68194816=>array(68194879,'CA'),68194880=>array(68204031,'US'),68204032=>array(68204159,'CU'),68204160=>array(68305407,'US'),68305408=>array(68305919,'MX'),68305920=>array(68978687,'US'),68978688=>array(68980735,'CA'),68980736=>array(69109759,'US'),69109760=>array(69111807,'CA'),69111808=>array(71670208,'US'),71670209=>array(71670209,'NL'),71670210=>array(83886079,'US'));
